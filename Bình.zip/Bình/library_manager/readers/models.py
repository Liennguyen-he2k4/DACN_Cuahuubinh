from django.db import models
from accounts.models import User

class ReaderProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.CharField(max_length=255, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    class Meta:
        verbose_name = "Hồ sơ độc giả"
        verbose_name_plural = "Danh sách độc giả"
    def __str__(self):
        return f"Hồ sơ độc giả: {self.user.username}"
