
from django.contrib import admin
from .models import ReaderProfile

admin.site.register(ReaderProfile)
