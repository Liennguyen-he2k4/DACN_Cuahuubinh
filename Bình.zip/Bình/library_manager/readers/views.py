from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from accounts.decorators import admin_required
from accounts.models import User
from .models import ReaderProfile
from .forms import ReaderProfileForm, ReaderUserForm

# Import lịch sử mượn 
from borrowreturn.models import BorrowTicket

@login_required
@admin_required
def reader_list(request):
    readers = User.objects.filter(role='reader')
    return render(request, "readers/reader_list.html", {"readers": readers})

@login_required
@admin_required
def reader_detail(request, reader_id):
    user = get_object_or_404(User, id=reader_id, role='reader')
    profile = ReaderProfile.objects.filter(user=user).first()

    history = BorrowTicket.objects.filter(reader=user).order_by("-borrow_date")

    return render(request, "readers/reader_detail.html", {
        "user": user,
        "profile": profile,
        "history": history
    })

@login_required
@admin_required
def reader_edit(request, reader_id):
    user = get_object_or_404(User, id=reader_id, role='reader')
    profile, created = ReaderProfile.objects.get_or_create(user=user)

    if request.method == "POST":
        user_form = ReaderUserForm(request.POST, instance=user)
        profile_form = ReaderProfileForm(request.POST, instance=profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()

            messages.success(request, "Cập nhật thông tin độc giả thành công!")
            return redirect("readers:reader_list")
    else:
        user_form = ReaderUserForm(instance=user)
        profile_form = ReaderProfileForm(instance=profile)

    return render(request, "readers/reader_edit.html", {
        "user_form": user_form,
        "profile_form": profile_form,
        "reader": user,
    })

@login_required
@admin_required
def reader_delete(request, reader_id):
    user = get_object_or_404(User, id=reader_id, role='reader')
    user.delete()
    messages.success(request, "Xóa độc giả thành công!")
    return redirect("readers:reader_list")
