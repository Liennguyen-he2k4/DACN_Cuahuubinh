from django import forms
from .models import ReaderProfile
from accounts.models import User

class ReaderProfileForm(forms.ModelForm):
    class Meta:
        model = ReaderProfile
        fields = ['address', 'phone']


class ReaderUserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'is_active_account']
