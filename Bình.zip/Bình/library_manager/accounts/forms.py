from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User


from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User


class LoginForm(AuthenticationForm):
    username = forms.CharField(
        widget=forms.TextInput(attrs={"class": "form-control"})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={"class": "form-control"})
    )


class RegisterForm(UserCreationForm):

    class Meta:
        model = User
        fields = ["username", "email", "password1", "password2"]

    username = forms.CharField(
        label="Tên đăng nhập",
        widget=forms.TextInput(attrs={"class": "form-control"})
    )

    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={"class": "form-control"})
    )

    password1 = forms.CharField(
        label="Mật khẩu",
        widget=forms.PasswordInput(attrs={"class": "form-control"})
    )

    password2 = forms.CharField(
        label="Nhập lại mật khẩu",
        widget=forms.PasswordInput(attrs={"class": "form-control"})
    )

    # Validate Email không trùng
    def clean_email(self):
        email = self.cleaned_data.get("email")
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("Email này đã được sử dụng.")
        return email

# -----------------------------
# FORM CHỈNH SỬA NGƯỜI DÙNG (ADMIN)
# -----------------------------
class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["username", "email", "role", "is_active_account"]
        labels = {
            "username": "Tên đăng nhập",
            "email": "Email",
            "role": "Vai trò",
            "is_active_account": "Kích hoạt tài khoản",
        }
        widgets = {
            "username": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
            "role": forms.Select(attrs={"class": "form-control"}),
        }
