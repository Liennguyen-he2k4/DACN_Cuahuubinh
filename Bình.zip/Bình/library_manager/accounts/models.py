from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('librarian', 'Thủ thư'),
        ('reader', 'Độc giả'),
    )

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='reader')
    is_paid = models.BooleanField(default=False)  
    is_active_account = models.BooleanField(default=True)
    email = models.EmailField(unique=True)
    def save(self, *args, **kwargs):
        # TỰ ĐỘNG PHÂN QUYỀN THEO ROLE
        if self.role == "admin":
            self.is_staff = True
            self.is_superuser = True

        elif self.role == "librarian":
            self.is_staff = True
            self.is_superuser = False

        else:  # reader
            self.is_staff = False
            self.is_superuser = False

        super().save(*args, **kwargs)
