from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .decorators import admin_required

from .models import User
from .forms import LoginForm, RegisterForm, UserUpdateForm


# --------------------------
# ĐĂNG NHẬP
# --------------------------
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)

            # Nếu là Admin hoặc Thủ thư → chuyển đến trang quản lý
            if user.role in ["admin", "librarian"]:
                return redirect('books:book_list_admin')

            # Nếu là Độc giả → về trang xem sách dạng shop
            return redirect('books:book_list_user')

    else:
        form = LoginForm()

    return render(request, 'accounts/login.html', {'form': form})

# --------------------------
# ĐĂNG XUẤT
# --------------------------
@login_required
def logout_view(request):
    logout(request)
    return redirect('accounts:login')


# --------------------------
# ĐĂNG KÝ 
# --------------------------
def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)

        if form.is_valid():
            user = form.save()
            messages.success(request, "Tạo tài khoản thành công! Hãy đăng nhập.")
            return redirect("accounts:login")

        else:
            print("❌ LỖI KHÔNG TẠO ĐƯỢC USER:", form.errors)

    else:
        form = RegisterForm()

    return render(request, "accounts/register.html", {"form": form})
# --------------------------
# DANH SÁCH NGƯỜI DÙNG
# --------------------------
@login_required
@admin_required
def user_list(request):
    users = User.objects.all()
    return render(request, 'accounts/user_list.html', {'users': users})


# --------------------------
# CHI TIẾT NGƯỜI DÙNG
# --------------------------
@login_required
@admin_required
def user_detail(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    return render(request, 'accounts/user_detail.html', {'user': user})


# --------------------------
# CHỈNH SỬA NGƯỜI DÙNG
# --------------------------
@login_required
@admin_required
def user_edit(request, user_id):
    user = get_object_or_404(User, pk=user_id)

    if request.method == 'POST':
        form = UserUpdateForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, "Cập nhật thành công!")
            return redirect('accounts:user_list')
    else:
        form = UserUpdateForm(instance=user)

    return render(request, 'accounts/user_edit.html', {'form': form})


# --------------------------
# XÓA NGƯỜI DÙNG
# --------------------------
@login_required
@admin_required
def user_delete(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    user.delete()
    messages.success(request, "Xóa tài khoản thành công!")
    return redirect('accounts:user_list')
