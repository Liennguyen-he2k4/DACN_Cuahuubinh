from django.urls import path
from . import views

app_name = "borrowreturn"

urlpatterns = [
    path("", views.borrow_list, name="borrow_list"),
    path("my/", views.my_borrows, name="my_borrows"),
    path("create/", views.borrow_create, name="borrow_create"),
    path("<int:ticket_id>/", views.borrow_detail, name="borrow_detail"),
    path("<int:ticket_id>/return/", views.return_book, name="return_book"),
    path("user/create/", views.user_borrow_create, name="user_borrow_create"),
        path("reserve/<int:book_id>/", views.reserve_book, name="reserve_book"),
    path("my-reservations/", views.my_reservations, name="my_reservations"),

]
