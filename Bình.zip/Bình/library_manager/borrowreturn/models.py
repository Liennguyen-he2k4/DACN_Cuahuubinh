from django.db import models
from django.utils import timezone
from datetime import timedelta

from accounts.models import User
from books.models import Book



def get_due_date():
    return timezone.now() + timedelta(days=2)


class BorrowTicket(models.Model):
    PAYMENT_METHODS = (
        ('stripe', 'Stripe'),
        ('cash', 'Tiền mặt'),
    )

    reader = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)

    borrow_date = models.DateTimeField(default=timezone.now)
    due_date = models.DateTimeField(default=get_due_date)  # ❗ sửa tại đây

    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS)
    fee = models.IntegerField(default=30000)

    is_paid = models.BooleanField(default=False)
    returned = models.BooleanField(default=False)
    class Meta:
        verbose_name = "Phiếu mượn"
        verbose_name_plural = "Danh sách phiếu mượn"
    def __str__(self):
        return f"BorrowTicket #{self.id} - {self.book.title}"


class ReturnTicket(models.Model):
    borrow_ticket = models.OneToOneField(BorrowTicket, on_delete=models.CASCADE)
    return_time = models.DateTimeField(default=timezone.now)
    late_fee = models.IntegerField(default=0)
    class Meta:
        verbose_name = "Phiếu trả"
        verbose_name_plural = "Danh sách phiếu trả"
    def __str__(self):
        return f"ReturnTicket #{self.id}"

class Reservation(models.Model):
    reader = models.ForeignKey('accounts.User', on_delete=models.CASCADE)
    book = models.ForeignKey('books.Book', on_delete=models.CASCADE)
    reserved_at = models.DateTimeField(auto_now_add=True)
    is_paid = models.BooleanField(default=False)
    is_notified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    FEE = 10000  # phí đặt trước

    def __str__(self):
        return f"{self.reader.username} – {self.book.title}"
