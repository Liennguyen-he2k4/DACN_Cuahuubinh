from django import forms
from .models import BorrowTicket
from .models import Reservation
class BorrowForm(forms.ModelForm):
    class Meta:
        model = BorrowTicket
        fields = ['book', 'payment_method']

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = []