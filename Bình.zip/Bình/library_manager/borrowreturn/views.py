from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
import stripe

from accounts.decorators import admin_required

from .models import BorrowTicket, ReturnTicket, Reservation
from .forms import BorrowForm
from books.models import Book
from payments.models import Payment

stripe.api_key = settings.STRIPE_SECRET_KEY


# ====================================================
# ADMIN – DANH SÁCH PHIẾU MƯỢN
# ====================================================
@login_required
@admin_required
def borrow_list(request):
    borrows = BorrowTicket.objects.order_by("-borrow_date")
    return render(request, "borrowreturn/borrow_list.html", {"borrows": borrows})


# ====================================================
# ADMIN – TẠO PHIẾU MƯỢN
# ====================================================
@login_required
@admin_required
def borrow_create(request):

    book_id = request.GET.get("book_id")
    initial = {}

    if book_id:
        try:
            initial["book"] = Book.objects.get(id=book_id)
        except Book.DoesNotExist:
            pass

    if request.method == "POST":
        form = BorrowForm(request.POST)

        if form.is_valid():
            borrow = form.save(commit=False)

            # Kiểm tra số lượng sách
            if borrow.book.quantity <= 0:
                messages.error(request, "Sách đã hết!")
                return redirect("borrowreturn:borrow_create")

            # Trừ kho
            book = borrow.book
            book.quantity -= 1
            book.status = "borrowed"
            book.save()

            borrow.save()

            # Tạo hóa đơn chưa thanh toán
            Payment.objects.create(
                user=borrow.reader,
                borrow_ticket=borrow,
                method=borrow.payment_method,
                amount=borrow.fee,
                status="unpaid",
            )

            messages.success(request, "Tạo phiếu mượn thành công!")
            return redirect("borrowreturn:borrow_list")

    else:
        form = BorrowForm(initial=initial)

    return render(request, "borrowreturn/borrow_create.html", {"form": form})


# ====================================================
# TRẢ SÁCH
# ====================================================
@login_required
@admin_required
def return_book(request, ticket_id):
    ticket = get_object_or_404(BorrowTicket, id=ticket_id)

    if ticket.returned:
        messages.error(request, "Phiếu này đã trả rồi.")
        return redirect("borrowreturn:borrow_list")

    # Tạo phiếu trả
    return_ticket = ReturnTicket.objects.create(borrow_ticket=ticket)

    # Nếu trễ hạn
    if return_ticket.return_time > ticket.due_date:
        return_ticket.late_fee = 20000
        return_ticket.save()

        # Tạo hóa đơn phạt
        Payment.objects.create(
            user=ticket.reader,
            borrow_ticket=ticket,
            method="cash",
            amount=20000,
            status="unpaid",
        )

    # Hoàn kho
    book = ticket.book
    book.quantity += 1
    book.status = "available"
    book.save()

    ticket.returned = True
    ticket.save()

    messages.success(request, "Đã trả sách thành công!")
    return redirect("borrowreturn:borrow_list")


# ====================================================
# CHI TIẾT PHIẾU MƯỢN
# ====================================================
@login_required
def borrow_detail(request, ticket_id):
    ticket = get_object_or_404(BorrowTicket, id=ticket_id)
    return render(request, "borrowreturn/borrow_detail.html", {"ticket": ticket})


# ====================================================
# LỊCH SỬ MƯỢN — ĐỘC GIẢ
# ====================================================
@login_required
def my_borrows(request):
    borrows = BorrowTicket.objects.filter(reader=request.user).order_by("-borrow_date")
    return render(request, "borrowreturn/my_borrows.html", {"borrows": borrows})


# ====================================================
# NGƯỜI DÙNG MƯỢN SÁCH
# ====================================================
@login_required
def user_borrow_create(request):
    book_id = request.GET.get("book_id")
    book = get_object_or_404(Book, id=book_id)

    if request.method == "POST":
        payment_method = request.POST.get("payment_method")

        # Kiểm tra sách còn không
        if book.quantity <= 0:
            messages.error(request, "Sách đã hết!")
            return redirect("books:book_detail", book_id=book.id)

        # Tạo phiếu mượn
        ticket = BorrowTicket.objects.create(
            reader=request.user,
            book=book,
            payment_method=payment_method,
            fee=30000,
        )

        # Trừ kho
        book.quantity -= 1
        book.status = "borrowed" if book.quantity > 0 else "out"
        book.save()

        # Nếu thanh toán bằng tiền mặt
        if payment_method == "cash":
            Payment.objects.create(
                user=request.user,
                borrow_ticket=ticket,
                method="cash",
                amount=ticket.fee,
                status="unpaid",
            )
            messages.success(request, "Bạn đã mượn sách thành công!")
            return redirect("borrowreturn:my_borrows")

        # Stripe payment
        payment = Payment.objects.create(
            user=request.user,
            borrow_ticket=ticket,
            method="stripe",
            amount=ticket.fee,
            status="unpaid",
        )

        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": "vnd",
                    "product_data": {"name": f"Phí mượn sách: {book.title}"},
                    "unit_amount": ticket.fee ,
                },
                "quantity": 1,
            }],
            mode="payment",
            success_url=settings.STRIPE_SUCCESS_URL,
            cancel_url=settings.STRIPE_CANCEL_URL,
            metadata={"payment_id": str(payment.id)}
        )

        payment.stripe_session_id = session.id
        payment.save()

        return redirect(session.url)

    return render(request, "borrowreturn/user_borrow_form.html", {
        "book": book,
        "payment_methods": ["cash", "stripe"],
    })


# ====================================================
# ĐẶT TRƯỚC SÁCH
# ====================================================
@login_required
def reserve_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)

    if Reservation.objects.filter(reader=request.user, book=book, is_paid=True).exists():
        messages.info(request, "Bạn đã đặt trước sách này rồi.")
        return redirect("borrowreturn:my_reservations")

    reservation = Reservation.objects.create(
        reader=request.user,
        book=book,
        is_paid=False,
    )

    Payment.objects.create(
        user=request.user,
        reservation=reservation,
        amount=Reservation.FEE,
        method="cash",
        status="unpaid"
    )

    messages.success(request, "Đặt trước thành công! Vui lòng thanh toán.")
    return redirect("borrowreturn:my_reservations")


# ====================================================
# LỊCH SỬ ĐẶT TRƯỚC
# ====================================================
@login_required
def my_reservations(request):
    reservations = Reservation.objects.filter(reader=request.user).order_by("-reserved_at")
    return render(request, "borrowreturn/my_reservations.html", {
        "reservations": reservations
    })
