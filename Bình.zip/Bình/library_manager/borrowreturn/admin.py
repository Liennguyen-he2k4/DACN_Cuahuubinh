from django.contrib import admin
from .models import BorrowTicket, ReturnTicket

admin.site.register(BorrowTicket)
admin.site.register(ReturnTicket)
