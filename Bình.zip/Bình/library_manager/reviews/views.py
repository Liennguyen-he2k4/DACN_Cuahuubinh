from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .models import Review
from .forms import ReviewForm
from books.models import Book
from accounts.decorators import admin_required


@login_required
def review_create(request, book_id):
    book = get_object_or_404(Book, id=book_id)

    if request.method == "POST":
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.book = book
            review.reader = request.user  # ← Thay user bằng reader
            review.save()
            messages.success(request, "Gửi đánh giá thành công!")
            return redirect("books:book_detail", book.id)
    else:
        form = ReviewForm()

    return render(request, "reviews/review_create.html", {"form": form, "book": book})


@login_required
def review_delete(request, review_id):
    review = get_object_or_404(Review, id=review_id)

    if request.user != review.reader and not request.user.is_staff:
        messages.error(request, "Bạn không có quyền xóa đánh giá này.")
        return redirect("books:book_detail", review.book.id)

    if request.method == "POST":
        review.delete()
        messages.success(request, "Xóa đánh giá thành công!")
        return redirect("books:book_detail", review.book.id)
    return render(request, "reviews/review_confirm_delete.html", {"review": review})
    
def review_list(request):
    reviews = Review.objects.all()
    return render(request, "reviews/review_list.html", {"reviews": reviews})