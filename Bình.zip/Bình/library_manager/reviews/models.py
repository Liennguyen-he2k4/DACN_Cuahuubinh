from django.db import models
from accounts.models import User
from books.models import Book

class Review(models.Model):
    reader = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    rating = models.IntegerField()  # 1–5
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name = "Đánh giá"
        verbose_name_plural = "Danh sách đánh giá"
    def __str__(self):
        return f"{self.reader.username} - {self.book.title} ({self.rating})"
