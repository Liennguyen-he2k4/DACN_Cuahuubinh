from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=255, unique=True)
    class Meta:
        verbose_name = "Thể loại sách"
        verbose_name_plural = "Danh mục thể loại"
    def __str__(self):
        return self.name


class Book(models.Model):
    STATUS_CHOICES = (
        ('available', 'Còn trong kho'),
        ('borrowed', 'Đang mượn'),
        ('damaged', 'Hư hỏng'),
    )

    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True)
    quantity = models.IntegerField(default=1)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES, default='available')
    image = models.ImageField(upload_to='books/', null=True, blank=True)
    class Meta:
        verbose_name = "Sách"
        verbose_name_plural = "Danh mục sách"
    def __str__(self):
        return f"{self.title} - {self.author}"
