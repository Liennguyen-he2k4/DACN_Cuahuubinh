from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from accounts.decorators import admin_required
from .models import Book, Category
from .forms import BookForm, CategoryForm
from django.db.models import Q


# ============================================================
# 🏠 TRANG CHỦ SHOP (DÀNH CHO NGƯỜI DÙNG)
# ============================================================
def home(request):
    books = Book.objects.all()
    categories = Category.objects.all()

    return render(request, "books/home.html", {
        "books": books,
        "categories": categories,
    })



# ============================================================
# 📚 DANH SÁCH SÁCH (GIAO DIỆN USER)
# ============================================================
def book_list_user(request):
    books = Book.objects.all()
    categories = Category.objects.all()

    # Bộ lọc
    query = request.GET.get("q")
    category_id = request.GET.get("category")

    if query:
        books = books.filter(title__icontains=query)

    if category_id:
        books = books.filter(category_id=category_id)

    return render(request, "books/book_list_user.html", {
        "books": books,
        "categories": categories,
    })



# ============================================================
# 📘 TRANG QUẢN LÝ SÁCH – DÀNH CHO ADMIN + THỦ THƯ
# ============================================================
@login_required
@admin_required
def book_list_admin(request):
    books = Book.objects.all()
    return render(request, "books/book_list_admin.html", {
        "books": books
    })



# ============================================================
# ➕ THÊM THỂ LOẠI (ADMIN)
# ============================================================
@login_required
@admin_required
def category_create(request):
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thêm thể loại thành công!")
            return redirect("books:book_list_admin")
    else:
        form = CategoryForm()

    return render(request, "books/category_create.html", {"form": form})



# ============================================================
# ➕ THÊM SÁCH (ADMIN)
# ============================================================
@login_required
@admin_required
def book_create(request):
    if request.method == "POST":
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Thêm sách thành công!")
            return redirect("books:book_list_admin")
    else:
        form = BookForm()

    return render(request, "books/book_create.html", {"form": form})



# ============================================================
# 📖 XEM CHI TIẾT SÁCH (AI CŨNG XEM)
# ============================================================
def book_detail(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    return render(request, "books/book_detail.html", {"book": book})



# ============================================================
# ✏️ CHỈNH SỬA SÁCH (ADMIN)
# ============================================================
@login_required
@admin_required
def book_edit(request, book_id):
    book = get_object_or_404(Book, id=book_id)

    if request.method == "POST":
        form = BookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            form.save()
            messages.success(request, "Cập nhật sách thành công!")
            return redirect("books:book_list_admin")
    else:
        form = BookForm(instance=book)

    return render(request, "books/book_edit.html", {
        "form": form,
        "book": book
    })



# ============================================================
# ❌ XÓA SÁCH (ADMIN)
# ============================================================
@login_required
@admin_required
def book_delete(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    book.delete()
    messages.success(request, "Xóa sách thành công!")
    return redirect("books:book_list_admin")

def book_search(request):
    query = request.GET.get("q", "")
    books = Book.objects.filter(
        Q(title__icontains=query) |
        Q(author__icontains=query) |
        Q(description__icontains=query)
    )

    return render(request, "books/book_search.html", {
        "query": query,
        "books": books
    })
