from django import forms
from .models import Book, Category

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name']


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = [
            'title', 'author', 'description',
            'category', 'quantity', 'status', 'image'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }
