from django.urls import path
from . import views

app_name = "books"

urlpatterns = [

    # SHOP USER
    path("", views.home, name="home"),
    path("books/", views.book_list_user, name="book_list_user"),
    path("books/<int:book_id>/", views.book_detail, name="book_detail"),

    # ADMIN MANAGEMENT
    path("manage/", views.book_list_admin, name="book_list_admin"),
    path("manage/create/", views.book_create, name="book_create"),
    path("manage/<int:book_id>/edit/", views.book_edit, name="book_edit"),
    path("manage/<int:book_id>/delete/", views.book_delete, name="book_delete"),

path("search/", views.book_search, name="search"),


    # CATEGORY
    path("category/create/", views.category_create, name="category_create"),
]
