from django.db.models import Sum, Count
from django.utils import timezone
from django.shortcuts import render
from accounts.decorators import admin_required
from books.models import Book
from borrowreturn.models import BorrowTicket
from payments.models import Payment
from inventory.models import ImportTransaction


@admin_required
def dashboard(request):

    # 1. Thống kê sách
    status_count = Book.objects.values("status").annotate(total=Count("id"))

    # 2. Lượt mượn hôm nay
    today = timezone.now().date()
    borrow_today = BorrowTicket.objects.filter(borrow_date__date=today).count()

    # 3. Doanh thu
    revenue_total = Payment.objects.filter(status="paid").aggregate(
        total=Sum("amount")
    )["total"] or 0

    # 4. Tổng tiền nhập sách
    total_import_cost = ImportTransaction.objects.aggregate(
        total=Sum("total_price")
    )["total"] or 0

    # 5. Vốn ban đầu
    initial_capital = 50_000_000

    # 6. Lợi nhuận = Doanh thu - Chi phí nhập sách
    profit = revenue_total - total_import_cost

    # 7. Vốn còn lại = Vốn ban đầu + Lợi nhuận
    capital_left = initial_capital + profit

    # 8. Lời / Lỗ
    status_profit = "Lời" if profit > 0 else "Lỗ"

    # 9. Doanh thu theo phương thức
    revenue_by_method = (
        Payment.objects.filter(status="paid")
        .values("method")
        .annotate(total=Sum("amount"))
    )

    return render(request, "reports/dashboard.html", {
        "status_count": status_count,
        "borrow_today": borrow_today,
        "revenue_total": revenue_total,
        "total_import_cost": total_import_cost,
        "initial_capital": initial_capital,
        "profit": profit,
        "capital_left": capital_left,
        "status_profit": status_profit,
        "revenue_by_method": revenue_by_method,
    })

    return render(request, "reports/dashboard.html", {
        "status_count": status_count,
        "borrow_today": borrow_today,
        "revenue_total": revenue_total,
        "total_import_cost": total_import_cost,
        "initial_capital": initial_capital,
        "profit": profit,
        "status_profit": status_profit,
        "revenue_by_method": revenue_by_method,
    })
