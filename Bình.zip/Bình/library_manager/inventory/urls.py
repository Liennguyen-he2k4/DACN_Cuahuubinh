from django.urls import path
from . import views

app_name = "inventory"

urlpatterns = [
    path("", views.import_list, name="import_list"),
    path("create/", views.import_create, name="import_create"),

    # Supplier
    path("suppliers/", views.supplier_list, name="supplier_list"),
    path("suppliers/create/", views.supplier_create, name="supplier_create"),
]
