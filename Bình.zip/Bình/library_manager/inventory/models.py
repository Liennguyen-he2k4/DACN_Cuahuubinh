from django.db import models
from books.models import Book

class Supplier(models.Model):
    name = models.CharField(max_length=255, verbose_name="Tên nhà cung cấp")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Số điện thoại")
    address = models.CharField(max_length=255, blank=True, verbose_name="Địa chỉ")

    class Meta:
        verbose_name = "Nhà cung cấp"
        verbose_name_plural = "Danh sách nhà cung cấp"

    def __str__(self):
        return self.name


class ImportTransaction(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE, verbose_name="Sách nhập")
    supplier = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, verbose_name="Nhà cung cấp")
    quantity = models.IntegerField(verbose_name="Số lượng nhập")
    price_per_book = models.IntegerField(verbose_name="Giá mỗi cuốn (VND)")
    total_price = models.IntegerField(verbose_name="Tổng tiền", blank=True, null=True)
    date = models.DateTimeField(auto_now_add=True, verbose_name="Ngày nhập")

    class Meta:
        verbose_name = "Phiếu nhập sách"
        verbose_name_plural = "Danh sách phiếu nhập"

    def save(self, *args, **kwargs):
        # Tự tính tổng tiền:
        self.total_price = self.quantity * self.price_per_book

        super().save(*args, **kwargs)

        # Cập nhật lại tồn kho sau khi lưu:
        book = self.book
        book.quantity += self.quantity
        book.save()

    def __str__(self):
        return f"Nhập {self.quantity} - {self.book.title}"
