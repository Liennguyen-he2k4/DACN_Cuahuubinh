from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from accounts.decorators import admin_required
from .models import ImportTransaction, Supplier
from .forms import ImportTransactionForm, SupplierForm


# Danh sách phiếu nhập
@login_required
@admin_required
def import_list(request):
    imports = ImportTransaction.objects.order_by("-date")
    return render(request, "inventory/import_list.html", {"imports": imports})


# Tạo phiếu nhập
@login_required
@admin_required
def import_create(request):
    if request.method == "POST":
        form = ImportTransactionForm(request.POST)

        if form.is_valid():
            form.save()
            messages.success(request, "Nhập sách thành công!")
            return redirect("inventory:import_list")
    else:
        form = ImportTransactionForm()

    return render(request, "inventory/import_create.html", {"form": form})


# Thêm nhà cung cấp
@login_required
@admin_required
def supplier_create(request):
    if request.method == "POST":
        form = SupplierForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thêm nhà cung cấp thành công!")
            return redirect("inventory:supplier_list")
    else:
        form = SupplierForm()

    return render(request, "inventory/supplier_create.html", {"form": form})


# Danh sách nhà cung cấp
@login_required
@admin_required
def supplier_list(request):
    suppliers = Supplier.objects.all()
    return render(request, "inventory/supplier_list.html", {"suppliers": suppliers})
