from django import forms
from .models import ImportTransaction, Supplier

class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = ['name', 'phone', 'address']


class ImportTransactionForm(forms.ModelForm):
    class Meta:
        model = ImportTransaction
        fields = ['book', 'supplier', 'quantity', 'price_per_book']
