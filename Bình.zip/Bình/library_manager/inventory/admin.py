from django.contrib import admin
from .models import ImportTransaction, Supplier

admin.site.register(ImportTransaction)
admin.site.register(Supplier)
