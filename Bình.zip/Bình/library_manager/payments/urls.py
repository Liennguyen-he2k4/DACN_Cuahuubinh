from django.urls import path
from . import views

app_name = "payments"

urlpatterns = [
    path("", views.payment_list, name="payment_list"),
    path("stripe/<int:ticket_id>/", views.create_stripe_payment, name="create_stripe_payment"),
    path("cash/<int:payment_id>/", views.cash_confirm, name="cash_confirm"),
    path("success/", views.payment_success, name="payment_success"),
    path("cancel/", views.payment_cancel, name="payment_cancel"),
    path("pay-reservation/<int:reservation_id>/", views.pay_reservation, name="pay_reservation"),
    path("webhook/", views.stripe_webhook, name="webhook"),
]
