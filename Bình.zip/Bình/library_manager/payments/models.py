from django.db import models
from accounts.models import User
from borrowreturn.models import BorrowTicket

class Payment(models.Model):
    PAYMENT_METHOD = (
        ('stripe', 'Stripe'),
        ('cash', 'Tiền mặt'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    borrow_ticket = models.ForeignKey(
        BorrowTicket,
        on_delete=models.CASCADE,
        null=True,       # ✅ Cho phép null
        blank=True       # ✅ Cho phép rỗng
    )
    reservation = models.ForeignKey('borrowreturn.Reservation', null=True, blank=True, on_delete=models.CASCADE)
    method = models.CharField(max_length=20, choices=PAYMENT_METHOD)
    amount = models.IntegerField()
    status = models.CharField(max_length=20, default="unpaid")  # unpaid / paid

    stripe_session_id = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name = "Thanh toán"
        verbose_name_plural = "Danh sách thanh toán"
    def __str__(self):
        return f"{self.user.username} - {self.method} - {self.amount}"
