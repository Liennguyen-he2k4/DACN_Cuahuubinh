from django import forms
from .models import Payment

class CashConfirmForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['status']
