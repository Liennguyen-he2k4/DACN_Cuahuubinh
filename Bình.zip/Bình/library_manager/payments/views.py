import stripe
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from accounts.decorators import admin_required

from borrowreturn.models import BorrowTicket, Reservation
from .models import Payment
from .forms import CashConfirmForm

stripe.api_key = settings.STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET = settings.STRIPE_WEBHOOK_SECRET


# ====================================================
# TẠO THANH TOÁN STRIPE (DÙNG CHO ADMIN)
# ====================================================
@login_required
def create_stripe_payment(request, ticket_id):
    ticket = get_object_or_404(BorrowTicket, id=ticket_id)

    # 1. Tạo Payment TRƯỚC
    payment = Payment.objects.create(
        user=request.user,
        borrow_ticket=ticket,
        method="stripe",
        amount=ticket.fee,
        status="unpaid",
    )

    # 2. Tạo Stripe Checkout — metadata phải chứa payment_id
    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{
            "price_data": {
                "currency": "vnd",
                "product_data": {"name": f"Phí mượn sách: {ticket.book.title}"},
                "unit_amount": ticket.fee * 100,
            },
            "quantity": 1,
        }],
        mode="payment",
        success_url=settings.STRIPE_SUCCESS_URL,
        cancel_url=settings.STRIPE_CANCEL_URL,
        metadata={"payment_id": str(payment.id)}
    )

    payment.stripe_session_id = session.id
    payment.save()

    return redirect(session.url)


# ====================================================
# PAYMENT CHO RESERVATION (ĐẶT TRƯỚC)
# ====================================================
@login_required
def pay_reservation(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id, reader=request.user)

    try:
        payment = Payment.objects.get(reservation=reservation)
    except Payment.DoesNotExist:
        messages.error(request, "Không tìm thấy hóa đơn thanh toán.")
        return redirect("borrowreturn:my_reservations")

    if payment.status == "paid":
        messages.info(request, "Bạn đã thanh toán phí đặt trước rồi.")
        return redirect("borrowreturn:my_reservations")

    # Nếu thanh toán bằng tiền mặt → xác nhận luôn
    if payment.method == "cash":
        payment.status = "paid"
        payment.save()

        reservation.is_paid = True
        reservation.save()

        messages.success(request, "Thanh toán thành công!")
        return redirect("borrowreturn:my_reservations")

    # Thanh toán bằng Stripe
    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{
            "price_data": {
                "currency": "vnd",
                "product_data": {"name": f"Đặt trước sách: {reservation.book.title}"},
                "unit_amount": payment.amount ,
            },
            "quantity": 1,
        }],
        mode="payment",
        success_url=settings.STRIPE_SUCCESS_URL,
        cancel_url=settings.STRIPE_CANCEL_URL,
        metadata={"payment_id": str(payment.id)}
    )

    payment.stripe_session_id = session.id
    payment.save()

    return redirect(session.url)


# ====================================================
# STRIPE WEBHOOK (CỰC QUAN TRỌNG)
# ====================================================
@csrf_exempt
def stripe_webhook(request):
    payload = request.body
    sig_header = request.META.get("HTTP_STRIPE_SIGNATURE")

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except Exception:
        return HttpResponse(status=400)

    # Khi thanh toán thành công
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        payment_id = session["metadata"]["payment_id"]

        payment = Payment.objects.get(id=payment_id)
        payment.status = "paid"
        payment.save()

        # Nếu thanh toán phiếu mượn
        if payment.borrow_ticket:
            ticket = payment.borrow_ticket
            ticket.is_paid = True
            ticket.save()

        # Nếu thanh toán phiếu đặt trước
        if payment.reservation:
            reservation = payment.reservation
            reservation.is_paid = True
            reservation.save()

    return HttpResponse(status=200)


# ====================================================
# XÁC NHẬN CASH PAYMENT (ADMIN)
# ====================================================
@login_required
@admin_required
def cash_confirm(request, payment_id):
    payment = get_object_or_404(Payment, id=payment_id)

    if request.method == "POST":
        payment.status = "paid"
        payment.save()

        # cập nhật borrow ticket
        if payment.borrow_ticket:
            ticket = payment.borrow_ticket
            ticket.is_paid = True
            ticket.save()

        # cập nhật reservation
        if payment.reservation:
            res = payment.reservation
            res.is_paid = True
            res.save()

        messages.success(request, "Xác nhận thanh toán thành công!")
        return redirect("payments:payment_list")

    return render(request, "payments/cash_confirm.html", {"payment": payment})


# ====================================================
# DANH SÁCH HÓA ĐƠN
# ====================================================
@login_required
@admin_required
def payment_list(request):
    payments = Payment.objects.order_by("-created_at")
    return render(request, "payments/payment_list.html", {"payments": payments})


def payment_success(request):
    return render(request, "payments/success.html")


def payment_cancel(request):
    return render(request, "payments/cancel.html")
